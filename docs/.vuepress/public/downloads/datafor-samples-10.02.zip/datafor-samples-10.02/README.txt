﻿Datafor 示例包 10.02 / Datafor sample package 10.02
====================================================

适用：Datafor 10.02 及以上，包括从旧版本升级到 10.02 的服务器。
      全新安装的 10.02 已经带这些示例，不需要再导入。

包里有什么
  - /public/Samples 文件夹里的示例报表：11 张仪表板（含 Drill-through Pages 子文件夹）、7 张分页报表
  - 示例用到的 8 个分析模型
  - 模型用到的 8 个文件数据集（CSV 原始数据）
  不含 workshop-model（每套 Datafor 本来就有），也不含 foodmart 的示例。

导入之前
  - 先把服务器升级到 10.02，确认 Datafor 已经启动、能登录。
  - 准备一个管理员账号。要导入到某个租户，就用那个租户的管理员，并记下租户 ID。

怎么导入（服务器可以不联网）
  1. 把整个包解压到任意目录，一般就在 Datafor 服务器上。
  2. Windows：双击 import.bat。
     Linux：在解压目录运行  sh import.sh
  3. 按提示输入服务器地址（默认 http://localhost:28080/datafor）、管理员账号、租户 ID（默认租户直接回车）和密码。
  4. 程序先列出要导入什么，确认后依次导入数据集 → 模型 → 报表，最后逐个核对，并在包目录下留一份 import-时间.log。
  经常要导入的，可以把地址、账号、租户填进 import-settings.txt，以后双击只问密码。

导入之后
  - 主页的“示例”会换成 /public/Samples 文件夹里最近修改的 5 个，封面第一次显示时自动生成（要等几秒）。
    开了白标“示例页面”的，主页照旧显示白标里的卡片。
  - /public/Samples 对登录用户只读、管理员可改；8 个模型和 8 个数据集的数据库连接给只读用户和创作者（SYS_Reader、SYS_Creator）读权限，和自带的 foodmart 一样，
    非管理员也能打开示例。

租户
  - 示例只导入到运行时填的那个租户，其他租户不受影响，主页照旧。
  - 文件数据集名在整台服务器上唯一：一台服务器上只能导入到一个普通租户，换个租户再导会提示数据集名已被占用，报表不会导入。
  - template0（新建租户用的模板）例外：用它的管理员导入（--user admin-/pentaho/template0 --tenant template0），
    它会有自己的一份数据集，名字后面加“ Template”，模型改指向这些数据集；默认租户导没导过都可以。
    之后从 template0 新建的租户会带上示例；已有的租户不变。

已经有内容时
  - 已存在的同名数据集、模型、报表默认跳过，可以放心重复运行。
  - 加 --overwrite 会覆盖它们：数据集清空后重传、模型和报表换成包里的内容。程序会先列出要替换的项，输入 yes 才继续。
  - 如果 /public/Samples 已经存在并放着你们自己的文件，程序会列出这些文件并先停下，回答 y 才继续。
    这些文件不会被改动，但主页按修改时间取这个文件夹里最新的 5 个，导入后主页可能显示示例。

不想要示例了
  在控制台删除 /public/Samples 文件夹；在数据源里删除下列 8 个模型和 8 个文件数据集。
  模型：Larkwood Retail Sales、Swiftline Global Network、Lifestats、Brightside Online Sales、Halden Group Financials、
        Kestrel Subscriptions、Halden Group Income Statement、Halden Group Balance Sheet
  数据集：Larkwood Retail Demo、Swiftline Global Demo、Lifestats Sample、Brightside Online Sample、Halden Financials Sample、
          Kestrel Churn Sample、Halden Income Statement Sample、Halden Balance Sheet Sample（template0 里名字后面多“ Template”）

其他
  - 用的是 Datafor 自带的 Java，不需要另外安装任何软件。找不到时会请你输入 bi-server 目录。
  - 服务器版本低于 10.02 时，程序会提示并停止，不做任何改动。
  - 参数：import --url 地址 --user 账号 --tenant 租户ID --overwrite --yes --lang zh|en
    --yes 不再询问任何确认。密码可以放在环境变量 DATAFOR_PASSWORD 里（无人值守时用），不要写进 import-settings.txt。


For: Datafor 10.02 or later, including servers upgraded to 10.02 from an earlier version.
     A fresh 10.02 installation already has these samples; there is nothing to import.

What is inside
  - The sample reports of the /public/Samples folder: 11 dashboards (incl. the Drill-through Pages subfolder) and 7 paginated reports
  - The 8 analysis models the samples use
  - The 8 file datasets behind those models (original CSV data)
  workshop-model is not included (every Datafor installation already has it); there are no foodmart samples.

Before you import
  - Upgrade the server to 10.02 first and make sure Datafor is running and you can sign in.
  - Have an administrator account ready. For a tenant, use an administrator of that tenant and note its tenant ID.

How to import (the server does not need internet access)
  1. Unzip the whole package anywhere, usually on the Datafor server.
  2. Windows: double-click import.bat.
     Linux: run  sh import.sh  in the unzipped folder.
  3. Enter the server address (default http://localhost:28080/datafor), the administrator account, the tenant ID
     (press Enter for the default tenant) and the password.
  4. It lists what it will import, then after you confirm imports datasets -> models -> reports, checks every item
     and leaves import-<time>.log in the package folder.
  If you import often, put the address, account and tenant into import-settings.txt; a double-click then only asks for the password.

After the import
  - The "Samples" on the home page become the 5 most recently modified files of /public/Samples; their covers are
    generated the first time they are shown (takes a few seconds). With a white-label "Sample pages" set, the home page
    keeps showing the white-label cards.
  - /public/Samples is read-only for signed-in users and editable by administrators; read-only users and creators (SYS_Reader, SYS_Creator) can read the
    8 models and the database connections of the 8 datasets, so non-administrators can open the samples.

Tenants
  - The samples go into the tenant entered at run time only; other tenants are not affected and keep their home page.
  - File dataset names are unique per server: the samples can be imported into one ordinary tenant per server; another
    tenant gets "dataset name already in use" and no reports are added.
  - template0 (the template new tenants are created from) is the exception: import with its administrator
    (--user admin-/pentaho/template0 --tenant template0). It gets its own copy of the datasets, named with " Template" at
    the end, and its models point at them, whether or not the default tenant has the samples. Tenants created from
    template0 afterwards get the samples; existing tenants are not changed.

When content already exists
  - Datasets, models and reports that already exist are skipped, so running it again is safe.
  - --overwrite replaces them: datasets are reloaded, models and reports get the package's content. The importer lists
    what it will replace and continues only after you type yes.
  - If /public/Samples already exists and holds files of your own, the importer lists them and stops until you answer y.
    Those files are not changed, but the home page shows the 5 most recently modified files of the folder, so it may
    show samples afterwards.

Removing the samples
  Delete the /public/Samples folder in the console, and delete these 8 models and 8 file datasets under data sources.
  Models: Larkwood Retail Sales, Swiftline Global Network, Lifestats, Brightside Online Sales, Halden Group Financials,
          Kestrel Subscriptions, Halden Group Income Statement, Halden Group Balance Sheet
  Datasets: Larkwood Retail Demo, Swiftline Global Demo, Lifestats Sample, Brightside Online Sample, Halden Financials Sample,
            Kestrel Churn Sample, Halden Income Statement Sample, Halden Balance Sheet Sample (in template0 with " Template" at the end)

Other notes
  - Uses the Java that ships with Datafor; nothing else to install. If it cannot find it, it asks for the bi-server folder.
  - On a server older than 10.02 it says so and stops before changing anything.
  - Options: import --url URL --user ACCOUNT --tenant TENANT_ID --overwrite --yes --lang zh|en
    --yes skips every confirmation. The password may be given in the DATAFOR_PASSWORD environment variable
    (unattended runs); never put it into import-settings.txt.
