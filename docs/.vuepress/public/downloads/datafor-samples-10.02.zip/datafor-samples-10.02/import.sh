#!/bin/sh
# Datafor sample import (Linux). Runs with the Java that comes with Datafor.
# Settings: import-settings.txt (fill once). Usage: sh import.sh [--url URL] [--user ACCOUNT] [--tenant ID] [--overwrite] [--yes]
HERE=$(cd "$(dirname "$0")" && pwd)
JAVA=""

if [ -n "$DATAFOR_JAVA" ] && [ -x "$DATAFOR_JAVA" ]; then JAVA="$DATAFOR_JAVA"; fi
if [ -z "$JAVA" ] && [ -n "$JAVA_HOME" ] && [ -x "$JAVA_HOME/bin/java" ]; then JAVA="$JAVA_HOME/bin/java"; fi
if [ -z "$JAVA" ]; then
  for j in /opt/*/bi-server/jre/bin/java /opt/bi-server/jre/bin/java /usr/local/*/bi-server/jre/bin/java \
           /home/*/*/bi-server/jre/bin/java /home/*/bi-server/jre/bin/java /data/*/bi-server/jre/bin/java; do
    if [ -x "$j" ]; then JAVA="$j"; break; fi
  done
fi
if [ -z "$JAVA" ] && command -v java >/dev/null 2>&1; then JAVA=java; fi
if [ -z "$JAVA" ]; then
  printf 'Java was not found. Enter the Datafor bi-server folder (e.g. /opt/datafor/bi-server): '
  read DFHOME
  if [ -x "$DFHOME/jre/bin/java" ]; then JAVA="$DFHOME/jre/bin/java"; fi
fi
if [ -z "$JAVA" ]; then
  echo "Java not found. Set DATAFOR_JAVA to the full path of java and run again."
  exit 2
fi

exec "$JAVA" -Dsamples.package="$HERE" -jar "$HERE/lib/datafor-samples-importer.jar" "$@"
