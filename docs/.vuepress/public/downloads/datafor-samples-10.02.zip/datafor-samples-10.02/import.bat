@echo off
rem Datafor sample import (Windows). Runs with the Java that comes with Datafor.
rem Settings: import-settings.txt (fill once). Usage: import.bat [--url URL] [--user ACCOUNT] [--tenant ID] [--overwrite] [--yes]
setlocal EnableDelayedExpansion
set "HERE=%~dp0"
set "JAVA="

if defined DATAFOR_JAVA if exist "%DATAFOR_JAVA%" set "JAVA=%DATAFOR_JAVA%"
if not defined JAVA if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "JAVA=%JAVA_HOME%\bin\java.exe"
if not defined JAVA (
  for %%D in (C D E F) do (
    if not defined JAVA if exist "%%D:\bi-server\jre\bin\java.exe" set "JAVA=%%D:\bi-server\jre\bin\java.exe"
    if not defined JAVA for /d %%P in ("%%D:\datafor*") do (
      if not defined JAVA if exist "%%~P\bi-server\jre\bin\java.exe" set "JAVA=%%~P\bi-server\jre\bin\java.exe"
    )
  )
)
if not defined JAVA (
  where java >nul 2>nul && set "JAVA=java"
)
if not defined JAVA (
  echo Java was not found. Enter the Datafor bi-server folder, e.g. D:\datafor-server\bi-server
  set /p "DFHOME=bi-server folder: "
  if exist "!DFHOME!\jre\bin\java.exe" set "JAVA=!DFHOME!\jre\bin\java.exe"
)
if not defined JAVA (
  echo Java not found in that folder. Set DATAFOR_JAVA to the full path of java.exe and run again.
  if "%~1"=="" pause
  exit /b 2
)

"%JAVA%" -Dsamples.package="%HERE%." -jar "%HERE%lib\datafor-samples-importer.jar" %*
set "RC=%ERRORLEVEL%"
if "%~1"=="" pause
exit /b %RC%
